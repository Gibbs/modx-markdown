Markdown Extra
==============
Version: 1.0.0
Authors:  Dan Gibbs <dan@goldcoastmedia.co.uk>

Write MODX documents in Markdown.

Git repo: https://github.com/GoldCoastMedia/modx-markdown-extra


Documentation
-------------

Full detailed documentation on using Markdown in MODX with this extension is 
available at:

