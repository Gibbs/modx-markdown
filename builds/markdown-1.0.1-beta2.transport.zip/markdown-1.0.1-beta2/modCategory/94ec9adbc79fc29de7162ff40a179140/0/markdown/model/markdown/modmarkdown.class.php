<?php
class modMarkdown extends xPDOSimpleObject {}