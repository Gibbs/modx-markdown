<?php
require_once (dirname(dirname(__FILE__)) . '/modmarkdown.class.php');
class modMarkdown_mysql extends modMarkdown {}